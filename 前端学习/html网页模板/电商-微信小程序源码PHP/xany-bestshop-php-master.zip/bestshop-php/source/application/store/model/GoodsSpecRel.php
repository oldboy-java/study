<?php

namespace app\store\model;

use app\common\model\GoodsSpecRel as GoodsSpecRelModel;

/**
 * 商品规格关系模型
 * Class GoodsSpecRel
 * @package app\store\model
 */
class GoodsSpecRel extends GoodsSpecRelModel
{
}
