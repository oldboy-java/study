<?php

namespace app\store\model;

use app\common\model\Region as RegionModel;

/**
 * 地区模型
 * Class Region
 * @package app\store\model
 */
class Region extends RegionModel
{

}
