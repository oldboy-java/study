<?php

namespace app\task\model;

use app\common\model\Setting as SettingModel;

/**
 * 系统设置模型
 * Class Wxapp
 * @package app\task\model
 */
class Setting extends SettingModel
{

}
